
from django.contrib import admin
from .models import Paciente

admin.site.register(Paciente)
