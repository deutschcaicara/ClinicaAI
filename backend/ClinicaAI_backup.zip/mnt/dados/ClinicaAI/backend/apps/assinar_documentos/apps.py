from django.apps import AppConfig

class Assinar_documentosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.assinar_documentos'
