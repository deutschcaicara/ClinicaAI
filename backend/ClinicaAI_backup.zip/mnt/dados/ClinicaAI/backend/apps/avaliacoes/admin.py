from django.contrib import admin
from .models import AvaliacoesModel

@admin.register(AvaliacoesModel)
class AvaliacoesAdmin(admin.ModelAdmin):
    list_display = ('nome', 'criado_em', 'atualizado_em')
