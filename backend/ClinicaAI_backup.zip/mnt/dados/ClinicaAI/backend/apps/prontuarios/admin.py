
from django.contrib import admin
from .models import Prontuario

admin.site.register(Prontuario)
