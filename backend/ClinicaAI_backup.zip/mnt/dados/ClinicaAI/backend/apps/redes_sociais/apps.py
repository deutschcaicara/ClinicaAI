from django.apps import AppConfig

class Redes_sociaisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.redes_sociais'
