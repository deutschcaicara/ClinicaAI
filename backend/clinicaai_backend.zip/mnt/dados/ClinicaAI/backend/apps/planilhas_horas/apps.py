from django.apps import AppConfig


class Planilhas_horasConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.planilhas_horas"
