import random
from django.core.management.base import BaseCommand
from profissionais.models import Profissional, Especialidade
from pacientes.models import Paciente
from exames.models import Exame
from agendamentos.models import Agendamento
from prontuarios.models import Prontuario
from django.contrib.auth.models import User

class Command(BaseCommand):
    help = 'Popula o banco de dados com dados de teste'

    def handle(self, *args, **kwargs):
        self.stdout.write("Populando banco de dados...\n")
        
        # Criando usuários de exemplo
        users = [
            User.objects.create_user(username=f"usuario{i}", password="senha123")
            for i in range(1, 6)
        ]

        # Criando especialidades
        especialidades = [
            "Cardiologia", "Dermatologia", "Ortopedia", "Neurologia", "Pediatria"
        ]
        for especialidade in especialidades:
            Especialidade.objects.create(nome=especialidade)

        # Criando profissionais de saúde
        for i in range(1, 6):
            profissional = Profissional.objects.create(
                nome=f"Profissional {i}",
                especialidade=Especialidade.objects.get(nome=random.choice(especialidades)),
                usuario=random.choice(users)
            )

        # Criando pacientes
        for i in range(1, 11):
            Paciente.objects.create(
                nome=f"Paciente {i}",
                idade=random.randint(20, 80),
                telefone=f"99999{random.randint(1000, 9999)}",
                email=f"paciente{i}@teste.com"
            )

        # Criando exames
        exames = [
            "Exame de sangue", "Raio X", "Ultrassom", "ECG", "Teste de glicose"
        ]
        for exame in exames:
            Exame.objects.create(nome=exame)

        # Criando agendamentos
        pacientes = Paciente.objects.all()
        profissionais = Profissional.objects.all()
        exames = Exame.objects.all()
        
        for i in range(1, 11):
            agendamento = Agendamento.objects.create(
                paciente=random.choice(pacientes),
                profissional=random.choice(profissionais),
                exame=random.choice(exames),
                data_agendamento="2024-12-01",
                hora_agendamento="09:00"
            )

        # Criando prontuários
        agendamentos = Agendamento.objects.all()
        for agendamento in agendamentos:
            Prontuario.objects.create(
                agendamento=agendamento,
                diagnostico="Diagnóstico fictício",
                receita="Receita fictícia",
                observacoes="Observações fictícias"
            )

        self.stdout.write(self.style.SUCCESS("Banco de dados populado com sucesso!"))
