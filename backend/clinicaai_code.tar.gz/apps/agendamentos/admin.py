from django.contrib import admin
from .models import Agendamento

admin.site.register(Agendamento)
