from django.apps import AppConfig


class Automacao_marketingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.automacao_marketing"
