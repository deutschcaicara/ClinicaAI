from django.apps import AppConfig


class Chat_ao_vivoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.chat_ao_vivo"
