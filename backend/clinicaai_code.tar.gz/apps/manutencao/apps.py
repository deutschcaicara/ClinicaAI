from django.apps import AppConfig


class ManutencaoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.manutencao"
