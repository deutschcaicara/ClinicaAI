from django.apps import AppConfig


class Marketing_smsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.marketing_sms"
