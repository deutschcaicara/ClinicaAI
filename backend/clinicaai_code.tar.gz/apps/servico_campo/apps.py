from django.apps import AppConfig


class Servico_campoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.servico_campo"
