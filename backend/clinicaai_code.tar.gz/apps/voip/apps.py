from django.apps import AppConfig


class VoipConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.voip"
